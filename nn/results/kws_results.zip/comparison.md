# Сравнение моделей

| Модель | Test Accuracy, % | Size, KB | Inference (CPU, ms) |
|---|---|---|---|
| FP32 | 96.46 | 956.0 | 1.78 |
| PTQ INT8 | 96.15 | 260.6 | 0.91 |
| QAT INT8 | 96.29 | 261.3 | 1.34 |

## Accuracy drop vs FP32

- **PTQ INT8**: +0.31 п.п.
- **QAT INT8**: +0.17 п.п.

## Compression ratio (vs FP32)

- **PTQ INT8**: 3.67×
- **QAT INT8**: 3.66×

## Графики

- `plots/accuracy_vs_size.png`
- `plots/cm_fp32_compare.png`, `plots/cm_ptq_compare.png`, `plots/cm_qat_compare.png`