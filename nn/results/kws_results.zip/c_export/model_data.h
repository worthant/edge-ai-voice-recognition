// Автоматически сгенерировано export_to_c.py
// Источник: ds_cnn_qat_int8.tflite
// Сгенерировано: 2026-04-27 14:31:55 UTC
// Размер: 267592 байт

#ifndef NN_MODEL_DATA_H_
#define NN_MODEL_DATA_H_

#include <cstdint>

extern const unsigned int g_model_data_size;
extern const unsigned char g_model_data[];

#endif  // NN_MODEL_DATA_H_
